﻿using System.Linq;
using EmployeeMySQLEntity.Models;
using EmployeeMySQLEntity.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EmployeeSQLEntity.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployeeService empServices;
        private readonly IDepartmentService depServices;
        public EmployeeController(IEmployeeService employee,IDepartmentService dep)
        {
            this.empServices = employee;
            this.depServices = dep;
        }
        public IActionResult Index()
        {
            var emps = empServices.Gets(true);
            return View("Index",emps);
        }

        public IActionResult Create()
        {
            ViewBag.Departments = depServices.Gets().Select(
                    dep=> new SelectListItem
                    {
                        Text=dep.DepartmentName,
                        Value=dep.Id.ToString()
                    }
                );
            return View();
        }

        [HttpPost]
        public IActionResult store(Employee emp)
        {
            if (ModelState.IsValid)
            {
                if (empServices.Save(emp))
                    return Redirect("/employee");
            }

            ViewBag.Departments = depServices.Gets().Select(
                    dep => new SelectListItem
                    {
                        Text = dep.DepartmentName,
                        Value = dep.Id.ToString()
                    }
                );
            return View("Create",emp);
        }
        public IActionResult Edit(int Id)
        {
            var emp = empServices.Get(Id);
            if (emp != null)
            {
                ViewBag.Departments = depServices.Gets().Select(
                    dep => new SelectListItem
                    {
                        Text = dep.DepartmentName,
                        Value = dep.Id.ToString()
                    }
                );
                return View("Edit", emp);
            }
            else return NotFound();
        }
        public IActionResult Update(Employee emp)
        {

            if (ModelState.IsValid)
            {
                if (empServices.Update(emp))
                    return Redirect("/");
            }

            ViewBag.Departments = depServices.Gets().Select(
                    dep => new SelectListItem
                    {
                        Text = dep.DepartmentName,
                        Value = dep.Id.ToString()
                    }
                );
            return View("Create", emp);
        }
        public IActionResult Detailed(int Id)
        {
            var emp = empServices.Get(Id);
            if (emp != null)
                return View("Detailed", emp);
            else return NotFound();
        }

        public IActionResult Delete(int Id)
        {
            var emp = empServices.Get(Id);
            if (emp != null)
                return View("Delete", emp);
            else return NotFound();
        }
        [HttpPost]
        public IActionResult Destroy(int Id)
        {
            var emp = empServices.Get(Id);
            if (emp != null)
            {
                if (empServices.Delete(emp))
                    return Redirect("/");
                else
                    return BadRequest();
            }
            else
                return NotFound();
        }
    }
}