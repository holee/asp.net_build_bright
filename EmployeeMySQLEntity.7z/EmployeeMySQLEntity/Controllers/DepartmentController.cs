﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeMySQLEntity.Models;
using EmployeeMySQLEntity.Services;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeMySQLEntity.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly IDepartmentService _departmentService;
        public DepartmentController(IDepartmentService departmentSerive)
        {
            this._departmentService = departmentSerive;
        }
        [ActionName("List")]
        public IActionResult Index()
        {
            var deps = _departmentService.Gets();
            return View("List", deps);
        }
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult store([Bind("DepartmentName")] Department dep)
        {
            if (ModelState.IsValid)
            {
                if (_departmentService.Save(dep))
                {
                    return RedirectToAction("List");
                }
            }
            return View("create", dep);
        }

        public IActionResult Edit(int? id)
        {
            var dep = _departmentService.Get(id.Value);
            if (dep != null)
                return View(dep);
            else
                return NotFound();
        }

        [HttpPost]
        public IActionResult Update([Bind("Id", "DepartmentName")] Department dep)
        {
            if (ModelState.IsValid)
            {
                if (_departmentService.Update(dep))
                {
                    return RedirectToAction("List");
                }
            }
            return View("create", dep);
        }

        [HttpPost]
        public IActionResult Destroy(int? id)
        {
            var dep = _departmentService.Get(id.Value);
            if (dep != null)
            {
                if (_departmentService.Delete(dep))
                {
                    return RedirectToAction("List");
                }
            }
            return NotFound();
        }

        [HttpGet]
        public IActionResult Delete(int? id)
        {
            var dep = _departmentService.Get(id.Value);
            if (dep != null)
            {
                return View("Delete", dep);
            }
            return NotFound();
        }

        public IActionResult Detailed(int? id)
        {
            var dep = _departmentService.Get(id.Value);
            if (dep != null)
            {
                return View("Detailed", dep);
            }
            return NotFound();
        }
    }
}