﻿using System.Collections.Generic;

namespace EmployeeMySQLEntity.Services
{
    public interface IDataServices<T> where T:class
    {
        bool Save(T TEntity);
        bool Update(T TEntity);
        bool Delete(T TEntity);
        T Get(int Id);
        List<T> Gets(bool include=false);
    }
}
