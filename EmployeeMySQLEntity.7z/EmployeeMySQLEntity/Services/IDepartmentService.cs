﻿using EmployeeMySQLEntity.Models;

namespace EmployeeMySQLEntity.Services
{
    public interface IDepartmentService:IDataServices<Department>
    {

    }
}
