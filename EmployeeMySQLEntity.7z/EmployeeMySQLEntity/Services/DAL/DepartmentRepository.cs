﻿using EmployeeMySQLEntity.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace EmployeeMySQLEntity.Services.DAL
{

    public class DepartmentRepository : IDepartmentService
    {
        private readonly AppDbContext _context;
        public DepartmentRepository(AppDbContext context)
        {
            _context = context;
        }
        public bool Delete(Department dep)
        {
            if(dep !=null)
            _context.Departments.Remove(dep);
            return _context.SaveChanges() > 0;
        }

        public Department Get(int Id)
        {
            var dep = _context.Departments.Find(Id);
            return dep;
        }

        public List<Department> Gets(bool include=false)
        {
            var deps = _context.Departments.ToList();
            if (include)
            {
                deps = _context.Departments.Include(emp=>emp.Employees).ToList();
            }
            return deps;
        }

        public bool Save(Department TEntity)
        {
            if (TEntity != null)
                _context.Departments.Add(TEntity);
            return _context.SaveChanges() > 0;
        }

        public bool Update(Department TEntity)
        {
            if (TEntity != null)
                _context.Departments.Update(TEntity);
            return _context.SaveChanges() > 0;
        }
    }
}
