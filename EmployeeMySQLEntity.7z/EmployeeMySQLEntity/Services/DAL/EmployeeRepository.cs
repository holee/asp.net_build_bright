﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using EmployeeMySQLEntity.Services.DAL;
using EmployeeMySQLEntity.Models;
using EmployeeMySQLEntity.Services;

namespace EmployeeMySQL.Services.DAL
{

    public class EmployeeRepository : IEmployeeService
    {
        private readonly AppDbContext _context;
        public EmployeeRepository(AppDbContext context)
        {
            _context = context;
        }
        public bool Delete(Employee emp)
        {
            if(emp !=null)
            _context.Employees.Remove(emp);
            return _context.SaveChanges() > 0;
        }

        public Employee Get(int Id)
        {
            var emp = _context.Employees.Find(Id);
            return emp;
        }

        public List<Employee> Gets(bool include=false)
        {
            var emps = _context.Employees.ToList();
            if (include)
            {
                emps = _context.Employees.Include(dep => dep.Department).ToList();
            }
            return emps;
        }

        public bool Save(Employee TEntity)
        {
            if (TEntity != null)
                _context.Employees.Add(TEntity);
            return _context.SaveChanges() > 0;
        }

        public bool Update(Employee TEntity)
        {
            if (TEntity != null)
                _context.Employees.Update(TEntity);
            return _context.SaveChanges() > 0;
        }
    }
}
