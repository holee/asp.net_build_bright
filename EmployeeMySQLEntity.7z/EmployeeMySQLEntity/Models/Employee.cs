﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeMySQLEntity.Models 
{
    public class Employee
    {
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Gender { get; set; }
        [Required]
        [Display(Name = "Department")]
        public int DepartmentId { get; set; }
        [Required]
        public string Address { get; set; }

        public Department Department { get; set; }
    }
}
