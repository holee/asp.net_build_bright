﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EmployeeMySQLEntity.Models
{
    public class Department
    {
        public Department()
        {
            Employees = new HashSet<Employee>();
        }
        public int Id { get; set; }

        [Required]
        [Display(Name = "Department")]
        public string DepartmentName { get; set; }

        public ICollection<Employee> Employees { get; set; }
    }
}
